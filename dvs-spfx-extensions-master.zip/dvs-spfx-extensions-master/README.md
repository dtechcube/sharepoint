# dvs-spfx-extensions

## Team Site Full Width Extension
An extension that manipulates some css to make the first section of the page a full width section and center the other sections in the page

![](TeamSiteFullWidth.gif)

## Print SharePoint Modern Page
An extension that creates floating button on the bottom of the page so you can export your page to PDF or PNG

![](PrintToPDF.gif)
![](PrintToImg.gif)
