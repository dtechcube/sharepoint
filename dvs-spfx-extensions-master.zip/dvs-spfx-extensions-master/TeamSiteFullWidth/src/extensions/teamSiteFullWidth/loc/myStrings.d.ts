declare interface ITeamSiteFullWidthApplicationCustomizerStrings {
  Title: string;
}

declare module 'TeamSiteFullWidthApplicationCustomizerStrings' {
  const strings: ITeamSiteFullWidthApplicationCustomizerStrings;
  export = strings;
}
