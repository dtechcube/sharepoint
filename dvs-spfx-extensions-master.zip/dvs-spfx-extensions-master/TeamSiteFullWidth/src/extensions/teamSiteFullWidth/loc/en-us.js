define([], function() {
  return {
    "Title": "TeamSiteFullWidthApplicationCustomizer"
  }
});