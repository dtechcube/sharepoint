define([], function() {
  return {
    "Caption": "Print this Page"
  }
});