declare interface IPrintPageApplicationCustomizerStrings {
  Caption: string;
}

declare module 'PrintPageApplicationCustomizerStrings' {
  const strings: IPrintPageApplicationCustomizerStrings;
  export = strings;
}
